package com.example.mongodbgeopoc.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.mongodbgeopoc.model.common.ApiError;

@ControllerAdvice
@RestController
public class CustomizedResponseEntityExceptionHandler {

	@ExceptionHandler(value = Exception.class)
	@ResponseBody
	public ResponseEntity<ApiError> exceptionHandler(Exception e) {
		if (e.getCause() instanceof com.mongodb.MongoSocketOpenException
				|| e.getCause() instanceof com.mongodb.MongoTimeoutException) {

			ApiError apiError = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR);
			apiError.setMessage("Error connecting to Database,Please try again later");
			return new ResponseEntity<>(apiError, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST);
		apiError.setMessage(e.getMessage());
		return new ResponseEntity<>(apiError, HttpStatus.BAD_REQUEST);
	}

}
