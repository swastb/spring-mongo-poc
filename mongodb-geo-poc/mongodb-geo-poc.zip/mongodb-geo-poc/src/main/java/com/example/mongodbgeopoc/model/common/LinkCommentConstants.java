package com.example.mongodbgeopoc.model.common;

public interface LinkCommentConstants {

	public String MENU_COMMENT = "Get food items associated with the trucks";
}
